package our.ent.ui;

import org.graalvm.nativeimage.hosted.Feature.BeforeAnalysisAccess;

/**
 *
 * @author xiaodong
 */
@com.oracle.svm.core.annotate.AutomaticFeature
class ReflectionFeature implements
        org.graalvm.nativeimage.hosted.Feature {

    @Override
    public void beforeAnalysis(BeforeAnalysisAccess access) {
    }
}
